-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 21 août 2020 à 18:23
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dbstudent`
--

-- --------------------------------------------------------

--
-- Structure de la table `attendance_table`
--

CREATE TABLE `attendance_table` (
  `id` int(15) NOT NULL,
  `iduser` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datesign` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `attendance_table`
--

INSERT INTO `attendance_table` (`id`, `iduser`, `name`, `datesign`, `time`) VALUES
(1, 5, '', '2020-08-20 13:10:03', '2020-08-20 13:10:03'),
(2, 5, 'test2', '2020-08-20 13:10:04', '2020-08-20 13:10:04'),
(3, 5, '', '2020-08-20 13:35:40', '2020-08-20 13:35:40'),
(4, 5, 'test2', '2020-08-20 13:35:40', '2020-08-20 13:35:40'),
(5, 5, '', '2020-08-20 13:44:51', '2020-08-20 13:44:51'),
(6, 5, 'test2', '2020-08-20 13:44:51', '2020-08-20 13:44:51'),
(7, 5, '', '2020-08-20 14:15:54', '2020-08-20 14:15:54'),
(8, 5, 'test2', '2020-08-20 14:15:54', '2020-08-20 14:15:54'),
(9, 0, '', '2020-08-20 14:40:13', '2020-08-20 14:40:13'),
(10, 0, '', '2020-08-20 14:41:28', '2020-08-20 14:41:28'),
(11, 0, '', '2020-08-20 14:42:44', '2020-08-20 14:42:44'),
(12, 0, '', '2020-08-20 14:43:02', '2020-08-20 14:43:02'),
(13, 0, '', '2020-08-20 14:43:55', '2020-08-20 14:43:55'),
(14, 0, '', '2020-08-20 14:44:25', '2020-08-20 14:44:25'),
(15, 10, '', '2020-08-20 22:14:47', '2020-08-20 22:14:47'),
(16, 10, 'luc gnando', '2020-08-20 22:14:47', '2020-08-20 22:14:47'),
(17, 11, '', '2020-08-21 02:44:41', '2020-08-21 02:44:41'),
(18, 11, 'JAUVAIN', '2020-08-21 02:44:41', '2020-08-21 02:44:41'),
(19, 11, 'JAUVAIN', '2020-08-21 02:47:33', '2020-08-21 02:47:33'),
(20, 11, 'JAUVAIN', '2020-08-21 02:47:35', '2020-08-21 02:47:35'),
(21, 11, 'JAUVAIN', '2020-08-21 02:47:37', '2020-08-21 02:47:37'),
(22, 11, 'JAUVAIN', '2020-08-21 02:50:05', '2020-08-21 02:50:05'),
(23, 11, 'JAUVAIN', '2020-08-21 02:50:07', '2020-08-21 02:50:07'),
(24, 11, 'JAUVAIN', '2020-08-21 02:50:46', '2020-08-21 02:50:46'),
(25, 11, 'JAUVAIN', '2020-08-21 02:52:42', '2020-08-21 02:52:42'),
(26, 11, 'JAUVAIN', '2020-08-21 02:53:35', '2020-08-21 02:53:35'),
(27, 11, 'JAUVAIN', '2020-08-21 02:54:22', '2020-08-21 02:54:22'),
(28, 11, 'JAUVAIN', '2020-08-21 02:56:29', '2020-08-21 02:56:29'),
(29, 11, 'JAUVAIN', '2020-08-21 02:57:02', '2020-08-21 02:57:02'),
(30, 11, 'JAUVAIN', '2020-08-21 02:57:51', '2020-08-21 02:57:51'),
(31, 11, 'JAUVAIN', '2020-08-21 02:58:09', '2020-08-21 02:58:09'),
(32, 11, 'JAUVAIN', '2020-08-21 02:58:23', '2020-08-21 02:58:23'),
(33, 0, '', '2020-08-21 02:58:57', '2020-08-21 02:58:57'),
(34, 0, '', '2020-08-21 02:59:00', '2020-08-21 02:59:00'),
(35, 0, '', '2020-08-21 02:59:24', '2020-08-21 02:59:24'),
(36, 0, '', '2020-08-21 02:59:26', '2020-08-21 02:59:26'),
(37, 0, '', '2020-08-21 03:00:29', '2020-08-21 03:00:29'),
(38, 0, '', '2020-08-21 03:00:44', '2020-08-21 03:00:44'),
(39, 0, '', '2020-08-21 03:01:06', '2020-08-21 03:01:06'),
(40, 0, '', '2020-08-21 03:01:09', '2020-08-21 03:01:09'),
(41, 0, '', '2020-08-21 03:01:39', '2020-08-21 03:01:39'),
(42, 0, '', '2020-08-21 03:01:40', '2020-08-21 03:01:40'),
(43, 12, '', '2020-08-21 17:58:08', '2020-08-21 17:58:08'),
(44, 12, 'test2020', '2020-08-21 17:58:09', '2020-08-21 17:58:09');

-- --------------------------------------------------------

--
-- Structure de la table `student_table`
--

CREATE TABLE `student_table` (
  `id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telephone` int(15) NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `student_table`
--

INSERT INTO `student_table` (`id`, `name`, `email`, `password`, `telephone`, `sexe`, `image`) VALUES
(2, 'Ahmed Ouattara', 'ouattara-hamed@hotmail.fr', 'Ã Ã Ã ', 2147483647, 'male', 'profil/163995vlcsnap-2020-07-08-17h47m46s9.png'),
(3, 'simplon', 'ohjsamuel@live.fr', 'Ã Ã Ã ', 8080808, 'male', 'profil/127084schema-general-architecture-mvc.png'),
(4, 'koko', 'koko@gmail.com', 'Ã Ã Ã ', 2147483647, 'female', 'profil/51148new.png'),
(5, 'test2', 'test@gmail.com', '000', 2147483647, 'autre', 'profil/232843schema-general-architecture-mvc.png'),
(6, 'test2', 'test2@gmail.com', '000', 2147483647, 'female', 'profil/575695django-logo-big.jpg'),
(7, 'test3', 'test3@gmail.com', '000', 2147483647, 'female', 'profil/121933vlcsnap-2020-07-08-17h47m46s9.png'),
(8, 'test4', 'test4@gmail.com', 'c6f057b86584942e415435ffb1fa93d4', 0, 'female', 'profil/559342new-project-13-780x405.png'),
(9, 'kouame konan bernadin', 'ko@gmail.com', 'c6f057b86584942e415435ffb1fa93d4', 2147483647, 'female', 'profil/875707new-project-13-780x405.png'),
(10, 'luc gnando', 'luc@gmail.com', 'c6f057b86584942e415435ffb1fa93d4', 87403030, 'autre', 'profil/163418capture_date.png'),
(11, 'JAUVAIN', 'jauvain@gmail.com', '4a7d1ed414474e4033ac29ccb8653d9b', 87403030, 'male', 'profil/937269capture2.png'),
(12, 'test2020', 'test2020@gmail.com', '5e37f8e899cb1ba0fa8e37b5004ebe3e', 87403030, 'male', 'profil/934649vlcsnap-2020-07-08-17h47m46s9.png');

-- --------------------------------------------------------

--
-- Structure de la table `teacher_table`
--

CREATE TABLE `teacher_table` (
  `id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `sexe` varchar(15) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `teacher_table`
--

INSERT INTO `teacher_table` (`id`, `name`, `email`, `password`, `telephone`, `sexe`, `image`) VALUES
(1, 'testprof', 'prof@gmail.com', '000', '+22587403030', 'male', 'prof/257001new.png'),
(2, 'testprof', 'testprof@gmail.com', 'c6f057b86584942e415435ffb1fa93d4', '+22587403030', 'female', 'prof/97739django-logo-big.jpg');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `attendance_table`
--
ALTER TABLE `attendance_table`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `student_table`
--
ALTER TABLE `student_table`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `teacher_table`
--
ALTER TABLE `teacher_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `attendance_table`
--
ALTER TABLE `attendance_table`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT pour la table `student_table`
--
ALTER TABLE `student_table`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `teacher_table`
--
ALTER TABLE `teacher_table`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
