<!DOCTYPE html>
<html>

<head>
    <title>page d'inscription</title>
    <link rel="stylesheet" type="text/css" href="css/styleinsc.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light" style="size: 20px;">
  <a class="navbar-brand" href="index.php">Accueil</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="index.php">Signer</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="prof.php">Espace administration</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

</nav>


<div class="FormInscris">
        <div class="form-text" style="color: white;">Signature </div>
            <div class="form-saisie" style="color:white">

                    <form id="register_form" method="post" action="treatment1.php" enctype="multipart/form-data"  onsubmit="return checkall();">
                     
                        <label for="email">Name:</label>
                        <input type="text" class="form-control" id="name" placeholder="Name" name="name">


                        <label for="pwd">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Email" name="email" required onkeyup="checkemail();">
                        <span id="email_status"></span>


                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Votre mot de passe" required maxlength="10">


                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password2" name="password2" placeholder="Confirmez votre password" required maxlength="10" onkeyup="checkpass();">
                        <span id="pass_status"></span>


                        <label for="telephone">Telephone:</label>
                        <input type="text" class="form-control" id="telephone" placeholder="telephone" name="telephone" onkeyup="checktelphone();">
                        <span id="telephone_status"></span>


                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="male" checked />
                        <label for="agree-term" class="label-agree-term">homme</label>

                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="female" />
                        <label for="agree-term" class="label-agree-term">Femme</label>

                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="autre" />
                        <label for="agree-term" class="label-agree-term">Autre</label>


                        <input type="file" class="form-control" id="img" placeholder="image" name="file">


                        <input type="submit" name="save" class="btn btn-primary" value="Register" style="background-color: #46cb49;"><br><br>
					Vous avez déjà un compte?&nbsp;<a href="signe.php">Cliquez ici</a>
    
                    </form>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

    <script>
        function checktelephone() //Fonction qui vérifie si le téléphone existe ou pas
        {
            var telephone = document.getElementById("telephone").value;

            if (telephone) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        telephone: telephone,
                    },
                    success: function(response) {
                        $('#phone_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#phone_status').html("");
                return false;
            }
        }

        function checkemail() //Fonction qui vérifie si le mail existe ou pas
        {
            var email = document.getElementById("email").value;

            if (email) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        email: email,
                    },
                    success: function(response) {
                        $('#email_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#email_status').html("");
                return false;
            }
        }

        function checkpass() //Fonction qui vérifie si les mMdp correspondent
        {
            var password2 = document.getElementById("password2").value;
            var password = document.getElementById("password").value;

            if (password2) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        password2: password2,
                        password: password,
                    },
                    success: function(response) {
                        $('#pass_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#pass_status').html("");
                return false;
            }
        }
        // Verification de tous les informations 

        function checkall() {
            var phonehtml = document.getElementById("phone_status").innerHTML;
            var emailhtml = document.getElementById("email_status").innerHTML;
            var passhtml = document.getElementById("pass_status").innerHTML;

            if ((phonehtml && emailhtml && passhtml) == "juste") {
                return true; //On peut s'inscrire
            } else {
                return false; //On ne peut pas s'incrire
            }
        }
    </script>
</body>

</html>